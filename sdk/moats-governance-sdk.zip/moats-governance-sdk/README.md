# Moats Governance SDK

A standalone TypeScript/JavaScript SDK for integrating with the Moats App Governance API.
Drop a single file into any JS/TS project — zero external dependencies.

## Installation

Copy `moats-governance-sdk.ts` into your project. No npm install needed.

## Quick Start

```ts
import { MoatsGovernanceSDK } from "./moats-governance-sdk";

const sdk = new MoatsGovernanceSDK({
  baseUrl: "https://your-app.replit.app",
});
```

## API Reference

### Projects

```ts
// List all governance projects
const projects = await sdk.projects.list();

// Get a single project
const project = await sdk.projects.get(1);

// Create a project (usually auto-synced from verified Moats)
const created = await sdk.projects.create({
  name: "My Protocol",
  contractAddress: "0xABC...",
  description: "Optional description",
});

// Top-100 Moat Points leaderboard for a project
const board = await sdk.projects.leaderboard(1);
```

### Proposals

```ts
// List all proposals (optional filters)
const all      = await sdk.proposals.list();
const active   = await sdk.proposals.list({ status: "active" });
const byMoat   = await sdk.proposals.list({ projectId: 1 });

// Aggregate counts
const summary  = await sdk.proposals.summary();
// => { total, active, passed, failed, pending, cancelled }

// Single proposal
const proposal = await sdk.proposals.get(42);

// Create a basic (FOR / AGAINST / ABSTAIN) proposal
const basic = await sdk.proposals.create({
  title: "Should we increase rewards?",
  description: "Detailed rationale...",
  projectId: 1,
  quorumType: "participation",
  quorumThreshold: 10,
  votingMethod: "basic",
  startDate: new Date().toISOString(),
  endDate: new Date(Date.now() + 7 * 864e5).toISOString(),
  createdBy: "0xYourWallet",
});

// Create a custom (weighted) proposal with options
const custom = await sdk.proposals.create({
  title: "Which strategy should we adopt?",
  description: "Choose one of the three paths.",
  projectId: 1,
  quorumType: "participation",
  quorumThreshold: 10,
  votingMethod: "single_choice",
  options: ["Strategy A", "Strategy B", "Strategy C"],
  startDate: new Date().toISOString(),
  endDate: new Date(Date.now() + 7 * 864e5).toISOString(),
  createdBy: "0xYourWallet",
});

// Update a proposal
await sdk.proposals.update(42, {
  title: "Updated title",
  endDate: new Date(Date.now() + 14 * 864e5).toISOString(),
  status: "active",
});

// Soft-delete (cancel) a proposal
await sdk.proposals.delete(42);
```

### Votes

The SDK handles building the canonical signed message, calling your wallet signer, and submitting — all in one call.

#### Compatible signers

```ts
// wagmi / viem
const signer = (msg: string) => signMessageAsync({ message: msg });

// ethers v6
const signer = (msg: string) => wallet.signMessage(msg);

// Raw MetaMask
const signer = (msg: string) =>
  window.ethereum.request({
    method: "personal_sign",
    params: [msg, walletAddress],
  });
```

#### Casting votes

```ts
// List votes for a proposal
const votes = await sdk.votes.list(42);

// Check a wallet's voting power (Moat Points)
const power = await sdk.votes.votingPower(42, "0xYourWallet");
// => { walletAddress, moatPoints, contractAddress }

// Cast a basic vote (FOR / AGAINST / ABSTAIN)
const vote = await sdk.votes.castBasicVote(
  proposalId,
  "for",           // "for" | "against" | "abstain"
  "0xYourWallet",
  signerFn
);

// Cast a weighted vote (custom proposals only)
// Percentages must sum to exactly 100
const vote = await sdk.votes.castWeightedVote(
  proposalId,
  { "Strategy A": 60, "Strategy B": 40 },
  "0xYourWallet",
  signerFn
);
```

### Admins

```ts
// List all admins (optional project filter)
const admins = await sdk.admins.list();
const admins = await sdk.admins.list({ projectId: 1 });

// Grant admin rights to a wallet
const admin = await sdk.admins.add({
  walletAddress: "0xNewAdmin",
  projectId: 1,
});

// Revoke an admin
await sdk.admins.remove(admin.id);
```

### Verified Moats

```ts
// List all Moats verified by the Moats protocol (10-min server-side cache)
const moats = await sdk.moats.listVerified();
// => [{ contractAddress, name, network, description, tags }, ...]
```

## Error Handling

Failed requests throw a `MoatsApiError` with `status` (HTTP code) and `body` properties.

```ts
import { MoatsGovernanceSDK, MoatsApiError } from "./moats-governance-sdk";

try {
  await sdk.votes.castBasicVote(proposalId, "for", wallet, signer);
} catch (err) {
  if (err instanceof MoatsApiError) {
    console.error(err.status, err.message);
    // 400 "Voting is closed for this proposal"
    // 400 "Already voted on this proposal"
    // 401 "Invalid wallet signature"
  }
}
```

## TypeScript Types

All types are exported from the SDK file:

```ts
import type {
  Project, CreateProjectInput, LeaderboardEntry,
  Proposal, CreateProposalInput, UpdateProposalInput,
  ProposalStatus, ProposalSummary,
  Vote, VotingPower,
  Admin, AddAdminInput,
  VerifiedMoat,
  BasicChoice, VotingMethod, QuorumType,
  SignerFn, MoatsGovernanceSDKConfig,
} from "./moats-governance-sdk";
```

## Custom Fetch (Node.js / Testing)

```ts
import nodeFetch from "node-fetch";

const sdk = new MoatsGovernanceSDK({
  baseUrl: "https://your-app.replit.app",
  fetch: nodeFetch as unknown as typeof fetch,
});
```

## Quorum Types

| Value | Description |
|-------|-------------|
| participation | FOR + AGAINST + ABSTAIN all count |
| approval | Only FOR votes count |
| for_abstain | FOR + ABSTAIN count |
| percentage | % of total eligible voting power |
| fixed_token | Fixed token amount threshold |
| dual | Participation + approval minimums |
| veto | Passes unless opposition reaches threshold |
| dynamic | Adjusts based on historical participation |
| time_weighted | Quorum decreases over the voting period |
| tiered | Different levels per proposal type |
| security | Elevated requirements for critical changes |

## Voting Methods

| Value | Description |
|-------|-------------|
| basic | Standard FOR / AGAINST / ABSTAIN |
| single_choice | Voters pick one option (weighted UI) |
| approval_voting | Voters select multiple valid options |
| ranked_choice | Voters rank options |
| weighted | Voters distribute power across options |
| quadratic | Cost increases quadratically |

> **Note:** All non-basic voting methods use the weighted percentage allocation UI —
> voters allocate 0–100% across each option, totalling 100, and sign once.
